import React, { Fragment, useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import Modal from "react-bootstrap/Modal";
import { useRouter } from "next/router";
import plane from "../../../Image/plane6.gif";
import Button from "react-bootstrap/Button";
import { Dialog, Transition } from "@headlessui/react";

import { Disclosure } from "@headlessui/react";
import { ChevronUpIcon, PrinterIcon } from "@heroicons/react/solid";
import { SelectedData } from "../../../Feature/Action";
import { authCode, domain, siteID } from "../../../static/static";
import loaders from "../../../Image/load.gif";
import { ModalBody } from "react-bootstrap";
import Image from "next/image";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import morning from "../../../Image/morning.svg";
import noon from "../../../Image/noon.svg";
import night from "../../../Image/night.svg";
import evening from "../../../Image/evening.svg";
import { AllData } from "../../../Redux/ActionType";

const Dom_Int_OneWay = (props) => {
  const { allData, load } = props;
  const navigate = useRouter();
  const dispatch = useDispatch();

  const Result = allData;
  const flightResult = Result.flightResult;
  const airport = Result.airport;
  const airline = Result.airline;

  const [filtersort, setfiltersort] = useState(false);
  const [sort, setsort] = useState([]);
  const [sortStop, setsortStop] = useState([]);
  //  const [load, setLoad] = useState(false);
  const [modal, setmodal] = useState(0);
  const [save, setSave] = useState([]);
  const [AirResult, setAirResult] = useState(flightResult);
  const [AirResult2, setAirResult2] = useState(flightResult);

  const handleClose1 = () => setShow1(false);
  const [show1, setShow1] = useState(false);
  const [show, setShow] = useState(false);
  const [show2, setShow2] = useState(false);
  // const [aatt, setAatt] = useState([]);
  const [flightData, setFlightData] = useState({
    resultID: 1,
    valCarrier: "SG",
    fareType: "RP",
    gdsType: 12,
    cabinClass: 1,
    fare: {
      adultFare: 6534.0,
      childFare: 0.0,
      infantFare: 0.0,
      infantWsFare: 0.0,
      adultTax: 846.0,
      childTax: 0.0,
      infantTax: 0.0,
      infantWsTax: 0.0,
      adultMarkup: -0.0,
      childMarkup: 0.0,
      infantMarkup: 0.0,
      infantWsMarkup: 0.0,
      bagFees: 0.0,
      grandTotal: 7380.0,
      markupID: 248,
      markupType: "IN",
      totalMarkup: -0.0,
      grandOrgTotal: 7380.0,
      baseFare: 6534.0,
      totalTax: 846.0,
      YQTax: 0.0,
      OtherCharges: 0.0,
      offeredFare: 7333.45,
      ChargeBU: [
        {
          key: "SME",
          value: 7380.0,
        },
      ],
      ServiceFee: 0.0,
      gstPrice: 0.0,
      convinenceFeeMeta: 0.1,
      convinenceFeeStatusMeta: "NO",
      convenienceFees: 250.0,
    },
    outBound: [
      {
        SequenceNumber: "0",
        airline: "SG",
        orgAirline: "SG",
        flightID: "8107",
        flightNo: "8107",
        equipmentType: "737",
        equipmentTypeDes: "",
        fromAirport: "DEL",
        depDate: "2022-04-28T05:45:00",
        toAirport: "MAA",
        reachDate: "2022-04-28T08:50:00",
        opratingAirline: "SG",
        resDesignCode: "SA",
        sliceAndDiceCode: "0",
        fromTerminal: " 3",
        toTerminal: " 1",
        cabinClass: 1,
        eft: 185,
        estimateTime: 185,
        layOverTime: 0,
        fareType: "RP",
        baggage: "15 Kg",
        cabinBaggage: "7 Kg",
        tripIndicator: 0,
        mile: 0,
        isETicketEligible: false,
        remark: "",
        airlineName: "SpiceJet",
      },
    ],
    ownerType: "4-5372858174_0DELMAASG8107_121544991710916",
    booking_token: "4-5372858174_0DELMAASG8107_121544991710916",
    offerItemID: "OB",
    consId: "",
    outEFT: 185,
    maxSeat: 97,
    airline: "SG",
    isSliceDiceAvailable: false,
    isLCC: true,
    isRefundable: true,
    IsPanOrPassportRequired: false,
    gSTAllowed: false,
    isCouponAppilcable: false,
    isGSTMandatory: false,
    airlineRemark: "",
    lastTicketDate: "",
    ticketAdvisory: "",
  });
  const data = useSelector(SelectedData);

  // console.log("dataDOMINT" , data)
  const { currency_Name_rd } = useSelector((item) => item.currency_Reducer);
  /*Flight Details Modal Show */
  const handleClose2 = () => setShow2(false);
  const handleShow2 = (item) => {
    setShow1(true);
    setFlightData(item);
    console.log(item);
  };
  const [trans, setTrans] = useState(0);
  function openModal(e) {
    setShow(true);
    setTrans(e);
  }

  const handleClose = () => setShow(false);
  const handleShow = (e) => {
    setShow(true);
    const detail = e;
    setmodal(detail);
  };
  /*Flight Details Modal Show */
  const curr = currency_Name_rd.currency_Logo;

  const ConvertMinsToTime = ({ data }) => {
    let hours = Math.floor(data / 60);
    let minutes = data % 60;
    minutes = minutes < 10 ? "0" + minutes : minutes;
    return `${hours}h:${minutes}m`;
  };

  const convertFrom24To12Format = (time24) => {
    const [sHours, minutes] = time24.match(/([0-9]{1,2}):([0-9]{2})/).slice(1);
    const period = +sHours < 12 ? "AM" : "PM";
    const hours = +sHours % 12 || 12;

    return `${hours}:${minutes} ${period}`;
  };

  let [isOpen, setIsOpen] = useState(false);
  function closeModal() {
    setIsOpen(false);
  }

  const airlinePrice = AirResult2.reduce(function (r, a) {
    r[a.airline] = r[a.airline] || [];
    r[a.airline].push(a);
    return r;
  }, Object.create(null));
  const modAirlinearray = Object.keys(airlinePrice).map(function (key) {
    var value = airlinePrice[key];
    return {
      airlineCode: key.substring(0, 2),
      firstPrice: value[0].fare.grandTotal,
      alldata: value,
    };
  });
  const getUniqueSearches = uniqueByMultipleKey(modAirlinearray, [
    "airlineCode",
  ]);
  function uniqueByMultipleKey(arr, keyProps) {
    return Object.values(
      arr.reduce((uniqueMap, entry) => {
        const key = keyProps.map((k) => entry[k]).join("|");
        if (!(key in uniqueMap)) uniqueMap[key] = entry;
        return uniqueMap;
      }, {})
    );
  }

  const selectFile = async (e) => {
    const checked = e.target.checked;
    const airlineFly = e.target.value;
    // var arrTT = [];

    if (checked) {
      // alert("air", airlineFly);
      setsort([...sort, { name: e.target.value }]);
      const aab = sort.map((items) =>
        AirResult.filter((item) => item.airline === items.name)
      );
      console.log("abababaababa", aab);
      // setAirResult(aab);
      // const ab_data = AirResult.filter(
      //   (item) => item.airline === sort.map((item) => item.name)
      // );
      // console.log("ab_dataab_data", aab);
      // console.log(
      //   "ab_data",
      //   sort.map((item) => {
      //     return { name: item };
      //   })
      // );
    } else {
      const ab = sort.filter((item) => item !== e.target.value);
      setsort(ab);
    }

    // const airlineDataFilter = AirResult.filter(
    //   (item) => item.airline === airlineFly
    // );
    // const airlineDataFilters = airlineDataFilter.filter(
    //   (item) => item.airline !== airlineFly
    // );
    // checked
    //   ? setAirResult(airlineDataFilter)
    //   : setAirResult(airlineDataFilters);

    // console.log(
    //   "airlineDataFilter",
    //   airlineDataFilter.length,
    //   airlineDataFilter
    // );
    // if (airlineFly == airlineFly) {
    //   {
    //     checked
    //       ? setAirResult([...sort, ...airlinePrice[airlineFly]])
    //       : setAirResult(sort.filter((items) => items.airline != airlineFly));
    //   }
    //   {
    //     checked
    //       ? setsort([...sort, ...airlinePrice[airlineFly]])
    //       : setsort(sort.filter((items) => items.airline != airlineFly));
    //   }
    // }
    // console.log("sort", AirResult);
  };
  // console.log(
  //   "ab_data",
  //   sort.map((item) => item)
  // );

  console.log("sortsort", sort);

  var Stops = [];
  if (load) {
    if (flightResult.filter((item) => item.outBound == true)) {
      Stops.push(
        flightResult
          .filter((item) => !item.outBound[1])
          .map((item) => {
            return item;
          })
      );
    }
    if (flightResult.filter((item) => item.outBound == true)) {
      Stops.push(
        flightResult
          .filter((item) => item.outBound[1])
          .map((item) => {
            return item;
          })
      );
    }
    if (flightResult.filter((item) => item.outBound == true)) {
      Stops.push(
        flightResult
          .filter((item) => item.outBound[2])
          .map((item) => {
            return item;
          })
      );
    }
    if (flightResult.filter((item) => item.outBound == true)) {
      Stops.push(
        flightResult
          .filter((item) => item.outBound[3])
          .map((item) => {
            return item;
          })
      );
    }
    if (flightResult.filter((item) => item.outBound == true)) {
      Stops.push(
        flightResult
          .filter((item) => item.outBound[4])
          .map((item) => {
            return item;
          })
      );
    }
  }

  const stopFunction = (e) => {
    const checking = e.target.checked;
    const value = e.target.value;
    console.log("v", value);

    if (value == value) {
      if (checking == true) {
        setSave(AirResult);

        setsortStop(AirResult);
        setAirResult([
          ...sortStop,
          ...AirResult.filter((items) => items.outBound.length == value),
        ]);
      } else {
        setAirResult(save.filter((items) => items.outBound.length != value));
      }
    }
  };

  function departure(e) {
    if (e == "morning") {
      setAirResult([
        ...Result.flightResult.filter(
          (items) =>
            items.outBound[0].depDate.slice(11, 13) >= 5 &&
            items.outBound[0].depDate.slice(11, 13) < 12
        ),
      ]);
    }
    if (e == "afternoon") {
      setAirResult([
        ...Result.flightResult.filter(
          (items) =>
            items.outBound[0].depDate.slice(11, 13) >= 12 &&
            items.outBound[0].depDate.slice(11, 13) < 18
        ),
      ]);
    }
    if (e == "evening") {
      setAirResult([
        ...Result.flightResult.filter(
          (items) =>
            items.outBound[0].depDate.slice(11, 13) >= 18 &&
            items.outBound[0].depDate.slice(11, 13) < 24
        ),
      ]);
    }
    if (e === "night") {
      setAirResult([
        ...Result.flightResult.filter(
          (items) =>
            items.outBound[0].depDate.slice(11, 13) >= 0 &&
            items.outBound[0].depDate.slice(11, 13) < 5
        ),
      ]);
    }
  }

  function arrival(e) {
    if (e == "morning") {
      setAirResult([
        ...Result.flightResult.filter(
          (items) =>
            items.outBound[0].reachDate.slice(11, 13) >= 5 &&
            items.outBound[0].reachDate.slice(11, 13) < 12
        ),
      ]);
    }
    if (e == "afternoon") {
      setAirResult([
        ...Result.flightResult.filter(
          (items) =>
            items.outBound[0].reachDate.slice(11, 13) >= 12 &&
            items.outBound[0].reachDate.slice(11, 13) < 18
        ),
      ]);
    }
    if (e == "evening") {
      setAirResult([
        ...Result.flightResult.filter(
          (items) =>
            items.outBound[0].reachDate.slice(11, 13) >= 18 &&
            items.outBound[0].reachDate.slice(11, 13) < 24
        ),
      ]);
    }
    if (e === "night") {
      setAirResult([
        ...Result.flightResult.filter(
          (items) =>
            items.outBound[0].reachDate.slice(11, 13) >= 0 &&
            items.outBound[0].reachDate.slice(11, 13) < 5
        ),
      ]);
    }
  }

  const checkFare_Rule = async (items) => {
    setShow(false);
    setShow2(true);
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");

    var raw = JSON.stringify({
      flightResult: items,
      adults: allData.adults,
      child: allData.child,
      infants: allData.infants,
      infantsWs: 0,
      currencyCode: curr,
      siteID: siteID,
    });

    var requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: raw,
      redirect: "follow",
    };

    const Apidata = await fetch(
      `http://${domain}/Flights/GetFlightFareRule?authcode=${authCode}`,
      requestOptions
    );
    const api_Result = await Apidata.json();
    console.log("api_Result", api_Result);
    const { fare, ...rest } = items;
    const datas = {
      fare: api_Result.fare,
    };
    const flight_Data = { ...rest, ...datas };
    console.log("flight_Data", flight_Data);
    if (
      api_Result.flightChecked === false ||
      api_Result.flightChecked === true
    ) {
      console.log("chekflight", flightData);
      dispatch({
        type: AllData,
        payload: {
          AllFlight_data: allData,
          SelectedData: flight_Data,
          inBoundData: {},
          Objdata: data,
        },
      });
      navigate.push("/flight/checkout");
      // navigate.push(
      //   {
      //     pathname: "/flight/checkout",
      //     query: {
      //       flight_data: JSON.stringify(flight_Data),
      //       AllFlight_Data: JSON.stringify(allData),
      //     },
      //   },
      //   "/flight/checkout"
      // );
    }
  };

  if (AirResult.length === 0) {
    setAirResult(AirResult2);
  }

  //   const flightResult_Data = AirResult.length === 0 ? flightResult : AirResult;
  // useEffect(() => {
  //   if (AirResult.length === 0) {
  //     setAirResult(AirResult);
  //   }
  // }, [AirResult]);

  const myLoader = ({ src, width, quality }) => {
    return `https://www.travomint.com/resources/images/airline-logo/${src}.png?w=${width}&q=${
      quality || 75
    }`;
  };

  console.log("AirResult", AirResult);

  return (
    <div className="w-100">
      <Container>
        <Row>
          <Col xl={3} xs={12}>
            <Button
              type="button"
              onClick={handleShow}
              className="btn-outline-fetfare btn-block d-none d-xl-block"
            >
              <div className="position-relative d-inline-block">
                <div class="waves-block">
                  <div class="waves wave-1"></div>
                  <div class="waves wave-2"></div>
                  <div class="waves wave-3"></div>
                </div>

                <span className="border-ringfr">
                  <i class="far fa-bell"></i>
                </span>
              </div>
              Get Fare Alert
            </Button>

            <Transition appear show={isOpen} as={Fragment}>
              <Dialog
                as="div"
                className="fixed bg-slate-200 inset-0 z-10 overflow-y-auto"
                onClose={closeModal}
              >
                <div className="min-h-screen px-4 text-center">
                  <Transition.Child
                    as={Fragment}
                    enter="ease-out duration-300"
                    enterFrom="opacity-0"
                    enterTo="opacity-100"
                    leave="ease-in duration-200"
                    leaveFrom="opacity-100"
                    leaveTo="opacity-0"
                  >
                    <Dialog.Overlay className="fixed inset-0" />
                  </Transition.Child>

                  {/* This element is to trick the browser into centering the modal contents. */}
                  <span
                    className="inline-block h-screen align-middle"
                    aria-hidden="true"
                  >
                    &#8203;
                  </span>
                  <Transition.Child
                    as={Fragment}
                    enter="ease-out duration-300"
                    enterFrom="opacity-0 scale-95"
                    enterTo="opacity-100 scale-100"
                    leave="ease-in duration-200"
                    leaveFrom="opacity-100 scale-100"
                    leaveTo="opacity-0 scale-95"
                  >
                    <div className="inline-block w-full max-w-md p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-xl rounded-2xl">
                      <Dialog.Title
                        as="h3"
                        className="text-lg font-medium leading-6 text-gray-900"
                      >
                        <i class="fa fa-user border-4 bg-blue-500 text-white border-white drop-shadow-xl outline-2 outline-gray-500 p-2 rounded-3xl"></i>
                        <span className="ml-2">Sign In</span>
                      </Dialog.Title>
                      <div className="mt-6"></div>
                    </div>
                  </Transition.Child>
                </div>
              </Dialog>
            </Transition>

            {/*============ filter sidebar ============*/}
            {filtersort ? (
              <div
                class="fade offcanvas-backdrop show d-xl-none"
                onClick={() => {
                  setfiltersort(!filtersort);
                }}
              ></div>
            ) : (
              ""
            )}
            <div
              class={
                "offcanvas offcanvas-sidenav offcanvas-start offcanvasbyfilter " +
                (filtersort ? "show" : "")
              }
            >
              <div class="offcanvas-header d-xl-none">
                <h5 class="offcanvas-title" id="offcanvasExampleLabel">
                  Filter
                </h5>
                <button
                  type="button"
                  class="btn-close text-reset"
                  onClick={() => {
                    setfiltersort(!filtersort);
                  }}
                  data-bs-dismiss="offcanvas"
                  aria-label="Close"
                ></button>
              </div>
              <div class="offcanvas-body">
                <aside className="filterres-custom">
                  <div className="bg-gray-50 rounded-xl mt-xl-3">
                    <div className="grid grid-cols-1 px-3 py-3 border-bottom">
                      <div className="grid grid-cols-2 text-left">
                        <p className="text-lg font-bold mb-0 text-black">
                          Filters
                        </p>
                        <div onClick={() => setAirResult(flightResult)}>
                          <p className="text-right mb-0 text-gray-500 font-normal reset-pointer">
                            Reset All
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 px-3 py-3 ">
                      <div className="grid grid-cols-1 text-left">
                        <Disclosure defaultOpen="true">
                          {({ open }) => (
                            <>
                              <Disclosure.Button className="flex  justify-between w-full  mb-2 text-sm font-medium text-left text-gray-900  rounded-lg ">
                                <span className="mb-0 text-black font-semibold">
                                  Choose Stop
                                </span>
                                <ChevronUpIcon
                                  className={`${
                                    open ? "transform rotate-180" : ""
                                  } w-5 h-5 text-gray-900`}
                                />
                              </Disclosure.Button>

                              {Stops.filter((items) => items.length > 0).map(
                                (items, i) => (
                                  <Disclosure.Panel className="px-2 pt-1 rounded-2xl pb-2 text-sm text-gray-900">
                                    {items[0].outBound.length == 1 ? (
                                      <div>
                                        {" "}
                                        <input
                                          type="checkbox"
                                          value={items[0].outBound.length}
                                          onClick={(e) => stopFunction(e)}
                                        />
                                        <span className=" text-xs font-sans font-normal">
                                          {" "}
                                          Non-Stop
                                        </span>{" "}
                                        <span className="float-right">
                                          <i class="fa fa-rupee-sign"></i>{" "}
                                          {items[0].fare.grandTotal}
                                        </span>
                                      </div>
                                    ) : (
                                      <span></span>
                                    )}

                                    {items[0].outBound.length == 2 ? (
                                      <div>
                                        {" "}
                                        <input
                                          type="checkbox"
                                          value={items[0].outBound.length}
                                          onClick={(e) => stopFunction(e)}
                                        />
                                        <span className=" text-xs font-sans font-bold">
                                          {" "}
                                          One-Stop
                                        </span>{" "}
                                        <span className="float-right">
                                          <i class="fa fa-rupee-sign"></i>{" "}
                                          {items[0].fare.grandTotal}
                                        </span>
                                      </div>
                                    ) : (
                                      <span></span>
                                    )}

                                    {items[0].outBound.length == 3 ? (
                                      <div>
                                        {" "}
                                        <input
                                          type="checkbox"
                                          defaultChecked="true"
                                          value={items[0].outBound.length}
                                          onClick={(e) => stopFunction(e)}
                                        />
                                        <span className=" text-xs font-sans font-bold">
                                          {" "}
                                          Two-Stop
                                        </span>{" "}
                                        <span className="float-right">
                                          <i class="fa fa-rupee-sign"></i>{" "}
                                          {items[0].fare.grandTotal}
                                        </span>
                                      </div>
                                    ) : (
                                      <span></span>
                                    )}

                                    {items[0].outBound.length == 4 ? (
                                      <div>
                                        {" "}
                                        <input
                                          type="checkbox"
                                          defaultChecked="true"
                                          value={items[0].outBound.length}
                                          onClick={(e) => stopFunction(e)}
                                        />
                                        <span className=" text-xs font-sans font-bold">
                                          {" "}
                                          Three-Stop
                                        </span>{" "}
                                        <span className="float-right">
                                          <i class="fa fa-rupee-sign"></i>{" "}
                                          {items[0].fare.grandTotal}
                                        </span>
                                      </div>
                                    ) : (
                                      <span></span>
                                    )}

                                    {items[0].outBound.length == 5 ? (
                                      <div>
                                        {" "}
                                        <input
                                          type="checkbox"
                                          defaultChecked="true"
                                          value={items[0].outBound.length}
                                          onClick={(e) => stopFunction(e)}
                                        />
                                        <span className=" text-xs font-sans font-bold">
                                          {" "}
                                          Four-Stop
                                        </span>{" "}
                                        <span className="float-right">
                                          <i class="fa fa-rupee-sign"></i>{" "}
                                          {items[0].fare.grandTotal}
                                        </span>
                                      </div>
                                    ) : (
                                      <span></span>
                                    )}

                                    {items[0].outBound.length == 6 ? (
                                      <div>
                                        {" "}
                                        <input
                                          type="checkbox"
                                          defaultChecked="true"
                                          value={items[0].outBound.length}
                                          onClick={(e) => stopFunction(e)}
                                        />
                                        <span className=" text-xs font-sans font-bold">
                                          {" "}
                                          Five-Stop
                                        </span>{" "}
                                        <span className="float-right">
                                          <i class="fa fa-rupee-sign"></i>{" "}
                                          {items[0].fare.grandTotal}
                                        </span>
                                      </div>
                                    ) : (
                                      <span></span>
                                    )}

                                    {items[0].outBound.length == 7 ? (
                                      <div>
                                        {" "}
                                        <input
                                          type="checkbox"
                                          defaultChecked="true"
                                          value={items[0].outBound.length}
                                          onClick={(e) => stopFunction(e)}
                                        />
                                        <span className=" text-xs font-sans font-bold">
                                          {" "}
                                          Six-Stop
                                        </span>{" "}
                                        <span className="float-right">
                                          <i class="fa fa-rupee-sign"></i>{" "}
                                          {items[0].fare.grandTotal}
                                        </span>
                                      </div>
                                    ) : (
                                      <span></span>
                                    )}
                                  </Disclosure.Panel>
                                )
                              )}
                            </>
                          )}
                        </Disclosure>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-xl mt-3">
                    <div className="w-100">
                      <Disclosure defaultOpen="true">
                        {({ open }) => (
                          <>
                            <div className="px-3 py-3">
                              <Disclosure.Button className="flex justify-between w-full text-sm font-medium text-left text-gray-900  rounded-lg focus:outline-none focus-visible:ring focus-visible:ring-white focus-visible:ring-opacity-75">
                                <span className="text-lg font-bold ">
                                  Departure Time
                                </span>
                                <ChevronUpIcon
                                  className={`${
                                    open ? "transform rotate-180" : ""
                                  } w-5 h-5 text-gray-900`}
                                />
                              </Disclosure.Button>
                            </div>

                            <Disclosure.Panel className="day-fltimeing-row">
                              <Row className="day-fltimeing">
                                <Col
                                  xs={6}
                                  onClick={(e) => departure("morning")}
                                  className="d-flex align-items-center justify-content-center flex-column"
                                >
                                  <div className="justify-center flex">
                                    <Image
                                      src={morning}
                                      width={30}
                                      height={25}
                                    />
                                  </div>
                                  <p className="text-xs font-semibold mb-0 mt-2 text-center">
                                    (05:00am - 11:59am)
                                  </p>
                                </Col>

                                <Col
                                  xs={6}
                                  onClick={(e) => departure("afternoon")}
                                  className="d-flex align-items-center justify-content-center flex-column"
                                >
                                  <div className="justify-center flex">
                                    <Image src={noon} width={30} height={25} />
                                  </div>
                                  <p className="text-xs font-semibold mb-0 mt-2 text-center">
                                    (12:00pm - 05:59pm)
                                  </p>
                                </Col>

                                <Col
                                  xs={6}
                                  onClick={(e) => departure("evening")}
                                  className="d-flex align-items-center justify-content-center flex-column"
                                >
                                  <div className="justify-center flex">
                                    <Image
                                      src={evening}
                                      width={30}
                                      height={25}
                                    />
                                  </div>
                                  <p className="text-xs font-semibold mb-0 mt-2 text-center">
                                    (06:00pm - 11:59pm)
                                  </p>
                                </Col>

                                <Col
                                  xs={6}
                                  onClick={(e) => departure("night")}
                                  className="d-flex align-items-center justify-content-center flex-column"
                                >
                                  <div className="justify-center flex">
                                    <Image src={night} width={30} height={25} />
                                  </div>
                                  <p className="text-xs font-semibold mb-0 mt-2 text-center">
                                    (00:00am - 04.59am)
                                  </p>
                                </Col>
                              </Row>
                            </Disclosure.Panel>
                          </>
                        )}
                      </Disclosure>
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-xl mt-3">
                    <div className="w-100">
                      <Disclosure defaultOpen="true">
                        {({ open }) => (
                          <>
                            <div className="px-3 py-3">
                              <Disclosure.Button className="flex justify-between w-full text-sm font-medium text-left text-gray-900  rounded-lg focus:outline-none focus-visible:ring focus-visible:ring-white focus-visible:ring-opacity-75">
                                <span className="text-lg font-bold ">
                                  Arrival Time
                                </span>
                                <ChevronUpIcon
                                  className={`${
                                    open ? "transform rotate-180" : ""
                                  } w-5 h-5 text-gray-900`}
                                />
                              </Disclosure.Button>
                            </div>

                            <Disclosure.Panel className="day-fltimeing-row">
                              <Row className="day-fltimeing">
                                <Col
                                  xs={6}
                                  onClick={(e) => arrival("morning")}
                                  className="d-flex align-items-center justify-content-center flex-column"
                                >
                                  <div className="justify-center flex">
                                    <Image
                                      src={morning}
                                      width={30}
                                      height={25}
                                    />
                                  </div>
                                  <p className="text-xs font-semibold mb-0 mt-2 text-center">
                                    (05:00am - 11:59am)
                                  </p>
                                </Col>

                                <Col
                                  xs={6}
                                  onClick={(e) => arrival("afternoon")}
                                  className="d-flex align-items-center justify-content-center flex-column"
                                >
                                  <div className="justify-center flex">
                                    <Image src={noon} width={30} height={25} />
                                  </div>
                                  <p className="text-xs font-semibold mb-0 mt-2 text-center">
                                    (12:00pm - 05:59pm)
                                  </p>
                                </Col>

                                <Col
                                  xs={6}
                                  onClick={(e) => arrival("evening")}
                                  className="d-flex align-items-center justify-content-center flex-column"
                                >
                                  <div className="justify-center flex">
                                    <Image
                                      src={evening}
                                      width={30}
                                      height={25}
                                    />
                                  </div>
                                  <p className="text-xs font-semibold mb-0 mt-2 text-center">
                                    (06:00pm - 11:59pm)
                                  </p>
                                </Col>

                                <Col
                                  xs={6}
                                  onClick={(e) => arrival("night")}
                                  className="d-flex align-items-center justify-content-center flex-column"
                                >
                                  <div className="justify-center flex">
                                    <Image src={night} width={30} height={25} />
                                  </div>
                                  <p className="text-xs font-semibold mb-0 mt-2 text-center">
                                    (00:00am - 04.59am)
                                  </p>
                                </Col>
                              </Row>
                            </Disclosure.Panel>
                          </>
                        )}
                      </Disclosure>
                    </div>
                  </div>

                  {/* ----------------------Flight sort checkbox------------------------------- */}

                  <div className="bg-gray-50 rounded-xl mt-3">
                    <div className="w-100">
                      <Disclosure defaultOpen="true">
                        {({ open }) => (
                          <>
                            <div className="px-3 py-3">
                              <Disclosure.Button className="flex justify-between w-full text-sm font-medium text-left text-gray-900  rounded-lg focus:outline-none focus-visible:ring focus-visible:ring-white focus-visible:ring-opacity-75">
                                <span className="text-lg font-bold ">
                                  Airline
                                </span>
                                <ChevronUpIcon
                                  className={`${
                                    open ? "transform rotate-180" : ""
                                  } w-5 h-5 text-gray-900`}
                                />
                              </Disclosure.Button>
                            </div>

                            <Disclosure.Panel className="day-fltimeing-row px-3 py-3 border-top">
                              {Result.airline.map((item, i) => {
                                const airlinePrice = AirResult2.filter(
                                  (items) => items.airline === item.code
                                );
                                // console.log("airlinePrice", airlinePrice);
                                return (
                                  <div className="d-flex mb-2">
                                    <div className="flex-grow-1 themeascheckbox font-14">
                                      <div class="form-check">
                                        <input
                                          class="form-check-input"
                                          type="checkbox"
                                          value={item.code}
                                          onClick={(e) => selectFile(e)}
                                          id={"flexairresult-" + i}
                                        />
                                        <label
                                          class="form-check-label text-sm"
                                          for={"flexairresult-" + i}
                                        >
                                          {item.name}
                                        </label>
                                      </div>
                                    </div>

                                    <div className="text-right pl-3">
                                      {/* <span className="text-sm font-bold">
                                  ₹ {airlinePrice[0].fare.grandTotal.toFixed(2, 0)}
                                </span> */}
                                    </div>
                                  </div>
                                );
                              })}
                            </Disclosure.Panel>
                          </>
                        )}
                      </Disclosure>
                    </div>
                  </div>
                </aside>

                <div class="text-center mt-4 d-xl-none">
                  <button
                    type="button"
                    className="btn btn-siteorange done-vel"
                    onClick={() => {
                      setfiltersort(!filtersort);
                    }}
                    data-bs-dismiss="offcanvas"
                    aria-label="Close"
                  >
                    Apply Filters
                  </button>
                </div>
              </div>
            </div>
            {/*============ endf filter sidebar ============*/}
          </Col>

          <Col xl={9} xs={12}>
            {/* 0------------------------------------airline select----------------------------------------- */}
            <Row className="formrow-airlines d-none d-md-flex">
              {getUniqueSearches.map((items, i) => (
                <Col xs={12} sm={6} md={3} xxl={2} className="mb-3">
                  <div
                    className="text-center boxalr"
                    onClick={() => setAirResult(items.alldata)}
                  >
                    <div className="d-flex align-items-center mb-3">
                      <div className=" justify-center inline-flex flex-wrap">
                        <img
                          src={`https://www.travomint.com/resources/images/airline-logo/${items.airlineCode}.png`}
                          className="w-10 rounded"
                        />
                      </div>
                      <p className="text-black font-semibold text-base mb-0 flex-grow-1 text-right pl-3">
                        {" "}
                        {items.airlineCode}{" "}
                      </p>
                    </div>

                    <div className="text-center amount text-white">
                      ₹ {items.firstPrice.toFixed(2, 0)}
                    </div>
                  </div>
                </Col>
              ))}

              <Col xs={12} sm={6} md={3} xxl={2} className="mb-3">
                <div
                  className="text-center boxalr fapl-re-4 h-100 d-flex justify-content-center align-items-center "
                  onClick={() => setAirResult(Result.flightResult)}
                >
                  <div className="font-semibold text-base">View All</div>
                </div>
              </Col>
            </Row>

            <Row className="align-items-center fitrrow tp">
              <Col xs={12} lg={6}>
                <div className="d-xl-none filterbybtn btn-outline-fetfare btn-block btn btn-primary">
                  <Row className="align-items-center">
                    <Col xs={6} className="text-left">
                      <a
                        href={void 0}
                        onClick={() => {
                          setfiltersort(!filtersort);
                        }}
                        className="text-primary"
                      >
                        <FontAwesomeIcon icon="fa-solid fa-filter" />
                        <span className="ml-2 font-semibold">Filter</span>
                      </a>
                    </Col>
                    <Col xs={6} className="text-right">
                      <h4 className="text-sm font-semibold text-black m-0 fapl-re-5">
                        {data.departure}
                        <span className="mx-3 fapl-re-1">
                          <FontAwesomeIcon icon="fa-solid fa-plane" />
                        </span>
                        {data.arrival}
                      </h4>
                    </Col>
                  </Row>
                </div>
              </Col>

              <Col xs={12} lg={6}>
                <Button
                  type="button"
                  onClick={handleShow}
                  className="btn-outline-fetfare getalmob btn-block d-xl-none mt-2 mt-lg-0"
                >
                  <div className="position-relative d-inline-block">
                    <div class="waves-block">
                      <div class="waves wave-1"></div>
                      <div class="waves wave-2"></div>
                      <div class="waves wave-3"></div>
                    </div>

                    <span className="border-ringfr">
                      <i class="far fa-bell"></i>
                    </span>
                  </div>
                  Get Fare Alert
                </Button>
              </Col>
            </Row>

            {/* 0------------------------------------airline select----------------------------------------- */}

            <div className="grid grid-cols-1 gap-4 pt-2 pb-4 mb-4 border-bottom">
              <Row className="align-items-end depflarriv">
                <Col xs={6} className="flp">
                  <h2 className="text-2xl lg:text-2xl font-bold text-black fapl-re-4">
                    Departure Flight
                  </h2>
                  <Row>
                    <Col xs={12} md={6} xl={12} className="d-none d-xl-block">
                      <h4 className="text-xl font-semibold text-black mb-3 fapl-re-5">
                        {data.departure}
                        <span className="mx-3 fapl-re-1">
                          <FontAwesomeIcon icon="fa-solid fa-plane" />
                        </span>
                        {data.arrival}
                      </h4>
                    </Col>

                    <Col xs={12} md={6} xl={12}>
                      <h5 className="text-base font-medium mt-0 mb-0 text-gray-600">
                        <span className="fapl-re-2">
                          <FontAwesomeIcon icon="fa-solid fa-calendar-days" />
                          {data.startDates}
                        </span>
                      </h5>
                    </Col>
                  </Row>
                </Col>
                <Col xs={6} className="text-right pr-4">
                  <h5 className="text-gray-500 text-sm font-meduim mb-0">
                    {" "}
                    <i class="fa fa-search mr-2"></i>{" "}
                    {AirResult.length === 0
                      ? flightResult.length
                      : AirResult.length}{" "}
                    Out of {flightResult.length} Result
                  </h5>

                  <div className="d-flex fapl-re-3 align-items-center">
                    <span className="text-sm pr-4 text-nowrap ">Sort By</span>
                    <div className="flex-grow-1">
                      <select class="form-select">
                        <option selected="selected" value="outFare.grandTotal">
                          Price (Low to High)
                        </option>
                        <option value="outEFT"> Duration (Low to High) </option>
                        <option value="depart-e"> Departure (Early) </option>
                        <option value="depart-l">Departure (Late)</option>
                        <option value="returns-e">Arrival (Early)</option>
                        <option value="returns-l">Arrival (Late)</option>
                      </select>
                    </div>
                  </div>
                </Col>
              </Row>
            </div>

            {AirResult.map((item) => {
              const outBoundCount = item.outBound.length;
              // const outBoundCount = 1;
              // console.log("item.outBound", item.outBound);
              const fromAirport = item.outBound[0].fromAirport;
              const toAirport = item.outBound[outBoundCount - 1].toAirport;
              const price = item.fare.grandTotal;

              return (
                <div>
                  <div className="filteroutbound-li fapl-re-6 grid lg:grid-cols-6 grid-cols-1 mb-4 rounded-xl">
                    <Row className="align-items-center">
                      <Col xs={4} md={8} xl={12} className="mdf-col">
                        <div className="d-flex flex-column align-items-start">
                          <div className="text-left">
                            {/* <Image
                          src={`https://www.travomint.com/resources/images/airline-logo/${item.outBound[0].airline}.png`}
                          className="w-10/12 down rounded-xl inline float-right"
                        /> */}
                            <div className="outbound-rtp d-inline-block">
                              <Image
                                loader={myLoader}
                                src={item.outBound[0].airline}
                                alt="Picture of the author"
                                width={50}
                                height={50}
                                className="rounded"
                              />
                            </div>
                          </div>
                          <div className="flex-grow=1  text-left">
                            {/* <span>{item.outBound[0].airlineName}</span> */}
                            {airline
                              .filter(
                                (airline) =>
                                  airline.code == item.outBound[0].airlineName
                              )
                              .map((airline) => airline.name)}

                            <span className="text-base text-black  font-bold">
                              {" "}
                              {item.outBound[0].airline}-
                              {item.outBound[0].flightNo}
                            </span>
                          </div>
                        </div>
                      </Col>

                      <Col xs={8} md={4} xl={12} className="mdf-col">
                        <button
                          onClick={(e) => handleShow2(item)}
                          className="downbtnflightt-dt btn btn-outline-secondary mt-2"
                        >
                          <i className="far fa-hand-point-right mr-1"></i>{" "}
                          Flight Details
                        </button>
                      </Col>
                    </Row>
                    <div className="col-span-4 lg:pl-14 lg:pr-14 pl-0 pr-0">
                      <div className="grid lg:grid-cols-4 grid-cols-1 grid-timelineway d-flex w-100 justify-content-between">
                        <div className="text-center">
                          <span className="text-lg text-black font-bold">
                            <div class="deslo-way mb-2">
                              <span className="badge bg-secondary">
                                {fromAirport}
                              </span>
                            </div>
                            <div className="my-1">
                              {convertFrom24To12Format(
                                item.outBound[0].depDate
                                  .split("T")[1]
                                  .substring(0, 5)
                              )}
                            </div>

                            <div className="text-gray-500 font-medium text-sm">
                              {item.outBound[0].depDate.split("T")[0]}
                            </div>
                          </span>
                        </div>
                        <div className="col-span-2 flex-grow-1 px-3 pt-2 dd-2">
                          <div className="w-100 text-center">
                            <div className="time-lineintwy">
                              <hr></hr>
                              <div className="d-flex justify-content-between align-items-center">
                                <FontAwesomeIcon icon="fa-solid fa-circle-dot" />
                                <FontAwesomeIcon icon="fa-solid fa-plane" />
                                <FontAwesomeIcon icon="fa-solid fa-circle-dot" />
                              </div>
                            </div>

                            <span className="text-xs text-black font-sans font-medium">
                              <div className="duration-intwy">
                                {/* {item.outBound[0].eft}  */}
                                <span className="d-block font-semibold layover">
                                  Layover Time
                                </span>

                                <div className="minttotime font-bold my-1 text-base text-black">
                                  <ConvertMinsToTime
                                    data={item.outBound[0].eft}
                                  />
                                </div>

                                <div className="text-xs stop capitalize font-normal">
                                  (
                                  {outBoundCount === 1
                                    ? "non-stop"
                                    : outBoundCount === 2
                                    ? "One-Stop"
                                    : outBoundCount === 3
                                    ? "Two-Stop"
                                    : outBoundCount === 4
                                    ? "Three-Stop"
                                    : null}
                                  )
                                </div>
                              </div>
                            </span>
                          </div>
                        </div>
                        <div className="text-center">
                          <span className="text-lg text-black font-bold">
                            <div class="deslo-way mb-2">
                              <span className="badge bg-secondary">
                                {toAirport}
                              </span>
                            </div>
                            <div className=" my-1">
                              {convertFrom24To12Format(
                                item.outBound[outBoundCount - 1].reachDate
                                  .split("T")[1]
                                  .substring(0, 5)
                              )}{" "}
                            </div>
                            <div className="text-gray-500 font-medium text-sm">
                              {
                                item.outBound[
                                  outBoundCount - 1
                                ].reachDate.split("T")[0]
                              }
                            </div>
                          </span>
                        </div>
                      </div>
                    </div>

                    <Row className="align-items-end">
                      {/* <Link
                      to="/flight/checkout"
                      state={{
                        AllFlight_Data: Result,
                        flight_data: item,
                      }}
                    > */}
                      <Col xs={6} lg={12}>
                        <div className="w-100 mb-3 from-btms">
                          <span className="text-lg font-nomal text-black font-sans pr-3 price-1 d-block frmid">
                            From
                          </span>
                          <span className="text-lg font-bold text-black font-sans price-2">
                            {curr} {price.toFixed(2, 0)}
                          </span>
                        </div>
                      </Col>
                      <Col xs={6} lg={12}>
                        <div className="text-left">
                          <button
                            className="btn btn-siteorange done-velres"
                            type="button"
                            onClick={() => openModal(item.resultID)}
                          >
                            {" "}
                            Book Now
                          </button>
                          {/* </Link> */}
                        </div>
                      </Col>
                    </Row>
                  </div>
                </div>
              );
            })}
          </Col>
        </Row>
      </Container>

      {/*----------------------- flight detail--------------------------- */}
      <Modal
        className="modalbooknow-classic"
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
        show={show1}
        onHide={handleClose1}
      >
        <Modal.Header closeButton>
          <Modal.Title>Flight Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p className="text-gray-700 tracking-wide font-normal text-sm leading-loose tracking-wide">
            The baggage information is just for reference. Please Check with
            airline before check-in. For more information, visit the airline's
            official website.
          </p>

          <Row className="my-4">
            <Col xs={12} xl={4} className="d-flex align-items-start mb-3">
              <div className="rounded overflow-hidden">
                <Image
                  loader={myLoader}
                  src={flightData.outBound[0].airline}
                  alt="Picture of the author"
                  width={50}
                  height={50}
                  className="rounded"
                />
              </div>
              <p className="flex-grow-1 m-0 pl-4 pt-1">
                <b className="font-semibold mb-0 text-xlbbage text-black">
                  {flightData.outBound[0].airlineName},{" "}
                  {flightData.outBound[0].airline}
                  {flightData.outBound[0].flightNo}
                </b>
                <br></br>
                <span className="text-base text-gray-500 font-medium text-xlbbage-sm">
                  Operated by {flightData.outBound[0].airlineName}
                </span>
              </p>
            </Col>
            <Col xs={12} xl={4} className="d-flex align-items-start mb-3">
              <div className="pr-2">
                <div className="faround-rfun d-flex align-items-center">
                  <i class="fa fa-briefcase fa-lg"></i>
                </div>
              </div>
              <div className="pl-2 pt-1">
                <p className="font-semibold mb-0 text-xlbbage text-black">
                  Cabin Baggage
                </p>
                <span className="text-base text-gray-500 font-medium text-xlbbage-sm">
                  {flightData.outBound[0].cabinBaggage} Per Person
                </span>
              </div>
            </Col>

            <Col xs={12} xl={4} className="d-flex align-items-start">
              <div className="pr-2">
                <div className="faround-rfun d-flex align-items-center">
                  <i class="fa fa-luggage-cart fa-lg"></i>
                </div>
              </div>
              <div className="pl-2 pt-1">
                <p className="font-semibold mb-0 text-xlbbage text-black">
                  Check-In Baggage
                </p>
                <span className="text-base text-gray-500 font-medium text-xlbbage-sm">
                  {flightData.outBound[0].baggage} Per Person
                </span>
              </div>
            </Col>
          </Row>

          <hr className="mb-4 mt-2 spbor"></hr>
          <div className="my-4">
            {flightData.outBound.map((items) => {
              return (
                <>
                  <div className="grid lg:grid-cols-4 grid-cols-1 grid-timelineway ipad-br d-flex w-100 justify-content-between">
                    <div className="text-center cont">
                      <span className="text-lg text-black font-bold">
                        <div class="deslo-way mb-2">
                          <span className="badge bg-secondary">
                            {airport
                              .filter(
                                (item) => item.airportCode == items.fromAirport
                              )
                              .map((airports) => {
                                return <>{airports.airportCode}</>;
                              })}
                          </span>
                        </div>
                        <div className="my-1">
                          {convertFrom24To12Format(
                            items.depDate.split("T")[1].substring(0, 5)
                          )}
                          <br></br>
                          {airport
                            .filter(
                              (item) => item.airportCode == items.fromAirport
                            )
                            .map((airports) => {
                              return (
                                <small className="text-gray-500 font-semibold">
                                  {airports.cityName}
                                </small>
                              );
                            })}
                        </div>

                        <div className="text-gray-500  text-sm font-medium">
                          {airport
                            .filter(
                              (item) => item.airportCode == items.fromAirport
                            )
                            .map((airports) => {
                              return <>{airports.airportName}</>;
                            })}

                          <span>
                            {airline
                              .filter((item) => item.code == items.airline)
                              .map((airlines) => airlines.name)}
                            ({items.airline})
                          </span>

                          <div className="text-gray-500 font-medium mt-2 text-sm">
                            <span className="mr-2">
                              <FontAwesomeIcon icon="fa-solid fa-calendar-days" />
                            </span>
                            {items.depDate.split("T")[0]}
                          </div>
                        </div>
                      </span>
                    </div>
                    <div className="col-span-2 flex-grow-1 px-3 pt-2 dd-1">
                      <div className="w-100 text-center">
                        <div className="time-lineintwy">
                          <hr></hr>
                          <div className="d-flex justify-content-between align-items-center">
                            <FontAwesomeIcon icon="fa-solid fa-circle-dot" />
                            <FontAwesomeIcon icon="fa-solid fa-plane" />
                            <FontAwesomeIcon icon="fa-solid fa-circle-dot" />
                          </div>
                        </div>

                        <span className="text-xs text-black font-sans font-medium">
                          <div className="duration-intwy"></div>
                        </span>
                      </div>
                    </div>

                    <div className="text-center cont">
                      <span className="text-lg text-black font-bold">
                        <div class="deslo-way mb-2">
                          <span className="badge bg-secondary">
                            {airport
                              .filter(
                                (item) => item.airportCode == items.toAirport
                              )
                              .map((airports) => {
                                return <>{airports.airportCode}</>;
                              })}
                          </span>
                        </div>
                        <div className="my-1">
                          {convertFrom24To12Format(
                            items.reachDate.split("T")[1].substring(0, 5)
                          )}
                          <br></br>
                          {airport
                            .filter(
                              (item) => item.airportCode == items.toAirport
                            )
                            .map((airports) => {
                              return (
                                <>
                                  <small className="text-gray-500 font-semibold">
                                    {airports.cityName}
                                  </small>
                                </>
                              );
                            })}
                        </div>

                        <div className="text-gray-500 text-sm font-medium">
                          {airport
                            .filter(
                              (item) => item.airportCode == items.toAirport
                            )
                            .map((airports) => {
                              return <>{airports.airportName}</>;
                            })}
                          <span>
                            {airline
                              .filter((item) => item.code == items.airline)
                              .map((airlines) => (
                                <>({items.airline})</>
                              ))}
                          </span>

                          <div className="text-gray-500 font-medium mt-2 text-sm">
                            <span className="mr-2">
                              <FontAwesomeIcon icon="fa-solid fa-calendar-days" />
                            </span>

                            {airline
                              .filter((item) => item.code == items.airline)
                              .map((airlines) => (
                                <>{items.depDate.split("T")[0]}</>
                              ))}
                          </div>
                        </div>
                      </span>
                    </div>
                  </div>

                  {/* <Modal.Footer >
          <Button className="foot" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer> */}
                </>
              );
            })}
          </div>
        </Modal.Body>
      </Modal>
      {/*----------------------- flight detail--------------------------- */}

      {/*----------------------- book Now--------------------------- */}
      <Modal
        className="modalbooknow-classic"
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
        show={show}
        onHide={handleClose}
      >
        <Modal.Header closeButton>
          <Modal.Title>Flight Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {AirResult.filter((items) => items.resultID == trans).map(
            (items, i) => (
              <>
                {items.outBound ? (
                  <div>
                    {items.outBound.length == 2 ? (
                      <div>
                        <div className=" grid grid-cols-1">
                          <div className="filteroutbound-li px-10 py-3 rounded-2xl">
                            <Row className="align-items-center">
                              <Col xs={12} lg={"auto"} className="mb-4 mb-lg-0">
                                <div className="w-100 text-center">
                                  <div className="">
                                    {/* <Image
                                    src={`https://www.travomint.com/resources/images/airline-logo/${items.airline}.png`}
                                    className="w-10/12 down rounded-xl inline float-right"
                                  /> */}
                                    <Image
                                      loader={myLoader}
                                      src={items.airline}
                                      alt="Picture of the author"
                                      width={50}
                                      height={50}
                                      className="rounded"
                                    />
                                  </div>

                                  <div className="w-100 mt-1">
                                    <span className="text-base text-black  font-bold">
                                      {Result.airline
                                        .filter(
                                          (item) => item.code == items.airline
                                        )
                                        .map((item, i) => (
                                          <span>{item.name} </span>
                                        ))}
                                    </span>
                                    <br />
                                    <span className="text-sm font-medium text-gray-500">
                                      {" "}
                                      <span>
                                        {items.outBound[0].airline}-
                                        {items.outBound[0].flightNo}
                                      </span>
                                    </span>
                                  </div>
                                </div>
                              </Col>
                              <Col xs={12} lg>
                                <div className="grid lg:grid-cols-4 grid-cols-1 grid-timelineway d-flex w-100 justify-content-between">
                                  <div className="text-center">
                                    <div className="deslo-way mb-2">
                                      <span className="badge bg-secondary">
                                        {items.outBound[0].fromAirport}
                                      </span>
                                    </div>

                                    <span className="text-gray-500 font-medium text-sm">
                                      {items.outBound[0].depDate}
                                    </span>
                                  </div>
                                  <div className="col-span-2 flex-grow-1 px-3 pt-1 dd-5">
                                    <div className="w-100 text-center">
                                      <div className="time-lineintwy">
                                        <hr></hr>
                                        <div className="d-flex justify-content-between align-items-center">
                                          <FontAwesomeIcon icon="fa-solid fa-circle-dot" />
                                          <FontAwesomeIcon icon="fa-solid fa-plane" />
                                          <FontAwesomeIcon icon="fa-solid fa-circle-dot" />
                                        </div>
                                      </div>

                                      <span className="text-xs text-black font-sans font-medium">
                                        <div className="duration-intwy">
                                          {/* {item.outBound[0].eft}  */}
                                          <div className="minttotime font-bold my-1 text-base text-black">
                                            2h
                                          </div>

                                          <div className="text-xs stop capitalize font-normal">
                                            (Non-Stop)
                                          </div>
                                        </div>
                                      </span>
                                    </div>
                                  </div>
                                  <div className="text-center">
                                    <div className="deslo-way mb-2">
                                      <span className="badge bg-secondary">
                                        {items.outBound[0].toAirport}
                                      </span>
                                    </div>

                                    <span className="text-gray-500 font-medium text-sm">
                                      {items.outBound[0].reachDate}
                                    </span>
                                  </div>
                                </div>
                              </Col>
                            </Row>
                            <div>
                              {/* <div className="grid grid-cols-4">
                      <div className="text-right px-2 pt-0 mb-4">
                        <span className=" text-lg font-bold text-black font-sans">
                          From
                        </span>
                      </div>
                      <div className="pl-4 col-span-3">
                        <span className="text-lg font-bold text-black font-sans">
                          <i class="fa fa-rupee-sign fa-sm "></i>{" "}
                        {items.fare.grandTotal}
                        </span>
                        <br />
                      </div>
                    </div> */}
                            </div>
                          </div>
                        </div>
                        {/* second */}
                        <div className=" grid grid-cols-1 ">
                          <div className="filteroutbound-li px-10 py-3 rounded-2xl mt-3">
                            <Row className="align-items-center">
                              <Col xs={12} lg={"auto"} className="mb-4 mb-lg-0">
                                <div className="w-100 text-center">
                                  <div className="">
                                    {/* <Image
                                    src={`https://www.travomint.com/resources/images/airline-logo/${items.airline}.png`}
                                    className="w-10/12 down rounded-xl inline float-right"
                                  /> */}
                                    <Image
                                      loader={myLoader}
                                      src={items.airline}
                                      alt="Picture of the author"
                                      width={50}
                                      height={50}
                                      className="rounded"
                                    />
                                  </div>

                                  <div className="w-100 mt-1">
                                    <span className="text-base text-black  font-bold">
                                      {Result.airline
                                        .filter(
                                          (item) => item.code == items.airline
                                        )
                                        .map((item, i) => (
                                          <span>{item.name} </span>
                                        ))}
                                    </span>
                                    <br />
                                    <span className="text-sm font-medium text-gray-500">
                                      {" "}
                                      <span>
                                        {items.outBound[1].airline}-
                                        {items.outBound[1].flightNo}
                                      </span>
                                    </span>
                                  </div>
                                </div>
                              </Col>
                              <Col xs={12} lg>
                                <div className="grid lg:grid-cols-4 grid-cols-1 grid-timelineway d-flex w-100 justify-content-between">
                                  <div className="text-center">
                                    <div className="deslo-way mb-2">
                                      <span className="badge bg-secondary">
                                        {items.outBound[1].fromAirport}
                                      </span>
                                    </div>
                                    <span className="text-gray-500 font-medium text-sm">
                                      {items.outBound[1].depDate}
                                    </span>
                                  </div>

                                  <div className="col-span-2 flex-grow-1 px-3 pt-1 dd-4">
                                    <div className="w-100 text-center">
                                      <div className="time-lineintwy">
                                        <hr></hr>
                                        <div className="d-flex justify-content-between align-items-center">
                                          <FontAwesomeIcon icon="fa-solid fa-circle-dot" />
                                          <FontAwesomeIcon icon="fa-solid fa-plane" />
                                          <FontAwesomeIcon icon="fa-solid fa-circle-dot" />
                                        </div>
                                      </div>

                                      <span className="text-xs text-black font-sans font-medium">
                                        <div className="duration-intwy">
                                          {/* {item.outBound[0].eft}  */}
                                          <div className="minttotime font-bold my-1 text-base text-black">
                                            2h
                                          </div>

                                          <div className="text-xs stop capitalize font-normal">
                                            (Non-Stop)
                                          </div>
                                        </div>
                                      </span>
                                    </div>
                                  </div>

                                  <div className="text-center">
                                    <div className="deslo-way mb-2">
                                      <span className="badge bg-secondary">
                                        {items.outBound[1].toAirport}
                                      </span>
                                    </div>
                                    <span className="text-gray-500 font-medium text-sm">
                                      {items.outBound[1].reachDate}
                                    </span>
                                  </div>
                                </div>
                              </Col>
                            </Row>
                            <div>
                              {/* <div className="grid grid-cols-4">
                      <div className="text-right px-2 pt-0 mb-4">
                        <span className=" text-lg font-bold text-black font-sans">
                          From
                        </span>
                      </div>
                      <div className="pl-4 col-span-3">
                        <span className="text-lg font-bold text-black font-sans">
                          <i class="fa fa-rupee-sign fa-sm "></i>{" "}
                        {items.fare.grandTotal}
                        </span>
                        <br />
                      </div>
                    </div> */}
                            </div>
                          </div>
                        </div>

                        {/* ??????? */}
                      </div>
                    ) : (
                      <div>
                        <div className=" grid grid-cols-1 ">
                          <div className="filteroutbound-li px-10 py-3 rounded-2xl">
                            <Row className="align-items-center">
                              <Col xs={12} lg={"auto"} className="mb-4 mb-lg-0">
                                <div className="w-100 text-center">
                                  <div className="">
                                    <Image
                                      loader={myLoader}
                                      src={items.airline}
                                      alt="Picture of the author"
                                      width={50}
                                      height={50}
                                      className="rounded"
                                    />
                                  </div>

                                  <div className="w-100 mt-1">
                                    <span className="text-base text-black  font-bold">
                                      {Result.airline
                                        .filter(
                                          (item) => item.code == items.airline
                                        )
                                        .map((item, i) => (
                                          <span>{item.name} </span>
                                        ))}
                                    </span>
                                    <br />
                                    <span className="text-sm font-medium text-gray-500">
                                      {" "}
                                      <span>
                                        {items.outBound[0].airline}-
                                        {items.outBound[0].flightNo}
                                      </span>
                                    </span>
                                  </div>
                                </div>
                              </Col>
                              <Col xs={12} lg>
                                <div className="grid lg:grid-cols-4 grid-cols-1 grid-timelineway d-flex w-100 justify-content-between">
                                  <div className="text-center">
                                    <div className="deslo-way mb-2">
                                      <span className="badge bg-secondary">
                                        {items.outBound[0].fromAirport}
                                      </span>
                                    </div>

                                    <span className="text-gray-500 font-medium text-sm">
                                      {items.outBound[0].depDate}
                                    </span>
                                  </div>
                                  <div className="col-span-2 flex-grow-1 px-3 pt-2 dd-3">
                                    <div className="w-100 text-center">
                                      <div className="time-lineintwy">
                                        <hr></hr>
                                        <div className="d-flex justify-content-between align-items-center">
                                          <FontAwesomeIcon icon="fa-solid fa-circle-dot" />
                                          <FontAwesomeIcon icon="fa-solid fa-plane" />
                                          <FontAwesomeIcon icon="fa-solid fa-circle-dot" />
                                        </div>
                                      </div>

                                      <span className="text-xs text-black font-sans font-medium">
                                        <div className="duration-intwy">
                                          {/* {item.outBound[0].eft}  */}
                                          <div className="minttotime font-bold my-1 text-base text-black">
                                            2h
                                          </div>

                                          <div className="text-xs stop capitalize font-normal">
                                            Non-Stop
                                          </div>
                                        </div>
                                      </span>
                                    </div>
                                  </div>
                                  <div className="text-center">
                                    <div className="deslo-way mb-2">
                                      <span className="badge bg-secondary">
                                        {items.outBound[0].toAirport}
                                      </span>
                                    </div>

                                    <span className="text-gray-500 font-medium text-sm">
                                      {items.outBound[0].reachDate}
                                    </span>
                                  </div>
                                </div>
                              </Col>
                            </Row>
                            <div></div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div>
                    {items.inBound.length == 2 ? (
                      <div>
                        {/* inBound */}
                        <div className=" grid grid-cols-1 ">
                          <div className="grid grid-cols-6 px-10 py-3 mt-3 up rounded-2xl">
                            <div>
                              <div className="grid grid-cols-3">
                                <div className="">
                                  {/* <Image
                                    src={`https://www.travomint.com/resources/images/airline-logo/${items.airline}.png`}
                                    className="w-10/12 down rounded-xl inline float-right"
                                  /> */}
                                  <Image
                                    loader={myLoader}
                                    src={items.airline}
                                    alt="Picture of the author"
                                    width={50}
                                    height={50}
                                    className="rounded"
                                  />
                                </div>

                                <div className="pl-4 col-span-2">
                                  <span className="text-sm text-black font-sans font-bold">
                                    {Result.airline
                                      .filter(
                                        (item) => item.code == items.airline
                                      )
                                      .map((item, i) => (
                                        <span>{item.name} </span>
                                      ))}
                                  </span>
                                  <br />
                                  <span className="text-xs text-black font-sans font-bold">
                                    {" "}
                                    <span>
                                      {items.inBound[0].airline}-
                                      {items.inBound[0].flightNo}
                                    </span>
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="col-span-5 px-14">
                              <div className="grid grid-cols-4">
                                <div className="text-center py-3">
                                  <span className="text-lg text-black font-bold">
                                    {items.inBound[0].depDate}{" "}
                                  </span>
                                  <span className="text-lg text-black font-bold">
                                    {items.inBound[0].fromAirport}
                                  </span>
                                </div>
                                <div className="col-span-2">
                                  <div className="grid grid-cols-10 mt-3  sd-3">
                                    <div className="col-span-4 pl-2">
                                      <Image
                                        src={plane}
                                        width={50}
                                        height={50}
                                        className="-top-5 relative"
                                      />
                                    </div>
                                    <div className="col-span-2 text-center relative -top-2">
                                      <span className="text-xs text-black font-sans">
                                        2h
                                      </span>
                                      <br />
                                      <span className="text-xs text-black font-sans">
                                        Non-Stop
                                      </span>
                                    </div>
                                    <div className="col-span-4 pr-2">
                                      <Image
                                        src={plane}
                                        width={50}
                                        height={50}
                                        className="-top-5 relative"
                                      />
                                    </div>
                                  </div>
                                </div>
                                <div className="text-center py-3">
                                  <span className="text-lg text-black font-bold">
                                    {items.inBound[0].reachDate}{" "}
                                  </span>
                                  <span className="text-lg text-black font-bold">
                                    {items.inBound[0].toAirport}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div>
                              {/* <div className="grid grid-cols-4">
                      <div className="text-right px-2 pt-0 mb-4">
                        <span className=" text-lg font-bold text-black font-sans">
                          From
                        </span>
                      </div>
                      <div className="pl-4 col-span-3">
                        <span className="text-lg font-bold text-black font-sans">
                          <i class="fa fa-rupee-sign fa-sm "></i>{" "}
                        {items.fare.grandTotal}
                        </span>
                        <br />
                      </div>
                    </div> */}
                            </div>
                          </div>
                        </div>

                        {/* second */}
                        {/* inBound */}
                        <div className=" grid grid-cols-1 ">
                          <div className="grid grid-cols-6 px-10 py-3 mt-3 up rounded-2xl">
                            <div>
                              <div className="grid grid-cols-3">
                                <div className="">
                                  {/* <Image
                                    src={`https://www.travomint.com/resources/images/airline-logo/${items.airline}.png`}
                                    className="w-10/12 down rounded-xl inline float-right"
                                  /> */}
                                  <Image
                                    loader={myLoader}
                                    src={items.airline}
                                    alt="Picture of the author"
                                    width={50}
                                    height={50}
                                    className="rounded"
                                  />
                                </div>

                                <div className="pl-4 col-span-2">
                                  <span className="text-sm text-black font-sans font-bold">
                                    {Result.airline
                                      .filter(
                                        (item) => item.code == items.airline
                                      )
                                      .map((item, i) => (
                                        <span>{item.name} </span>
                                      ))}
                                  </span>
                                  <br />
                                  <span className="text-xs text-black font-sans font-bold">
                                    {" "}
                                    <span>
                                      {items.inBound[1].airline}-
                                      {items.inBound[1].flightNo}
                                    </span>
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="col-span-5 px-14">
                              <div className="grid grid-cols-4">
                                <div className="text-center py-3">
                                  <span className="text-lg text-black font-bold">
                                    {items.inBound[1].depDate}{" "}
                                  </span>
                                  <span className="text-lg text-black font-bold">
                                    {items.inBound[1].fromAirport}
                                  </span>
                                </div>
                                <div className="col-span-2">
                                  <div className="grid grid-cols-10 mt-3  sd-2">
                                    <div className="col-span-4 pl-2">
                                      <Image
                                        src={plane}
                                        width={50}
                                        height={50}
                                        className="-top-5 relative"
                                      />
                                    </div>
                                    <div className="col-span-2 text-center relative -top-2">
                                      <span className="text-xs text-black font-sans">
                                        2h
                                      </span>
                                      <br />
                                      <span className="text-xs text-black font-sans">
                                        Non-Stop
                                      </span>
                                    </div>
                                    <div className="col-span-4 pr-2">
                                      <Image
                                        src={plane}
                                        width={50}
                                        height={50}
                                        className="-top-5 relative"
                                      />
                                    </div>
                                  </div>
                                </div>
                                <div className="text-center py-3">
                                  <span className="text-lg text-black font-bold">
                                    {items.inBound[1].reachDate}{" "}
                                  </span>
                                  <span className="text-lg text-black font-bold">
                                    {items.inBound[1].toAirport}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div>
                              {/* <div className="grid grid-cols-4">
                      <div className="text-right px-2 pt-0 mb-4">
                        <span className=" text-lg font-bold text-black font-sans">
                          From
                        </span>
                      </div>
                      <div className="pl-4 col-span-3">
                        <span className="text-lg font-bold text-black font-sans">
                          <i class="fa fa-rupee-sign fa-sm "></i>{" "}
                        {items.fare.grandTotal}
                        </span>
                        <br />
                      </div>
                    </div> */}
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div>
                        {/* inBound */}
                        <div className=" grid grid-cols-1 ">
                          <div className="grid grid-cols-6 px-10 py-3 mt-3 up rounded-2xl">
                            <div>
                              <div className="grid grid-cols-3">
                                <div className="">
                                  {/* <Image
                                    src={`https://www.travomint.com/resources/images/airline-logo/${items.airline}.png`}
                                    className="w-10/12 down rounded-xl inline float-right"
                                  /> */}
                                  <Image
                                    loader={myLoader}
                                    src={items.airline}
                                    alt="Picture of the author"
                                    width={50}
                                    height={50}
                                    className="rounded"
                                  />
                                </div>

                                <div className="pl-4 col-span-2">
                                  <span className="text-sm text-black font-sans font-bold">
                                    {Result.airline
                                      .filter(
                                        (item) => item.code == items.airline
                                      )
                                      .map((item, i) => (
                                        <span>{item.name} </span>
                                      ))}
                                  </span>
                                  <br />
                                  <span className="text-xs text-black font-sans font-bold">
                                    {" "}
                                    <span>
                                      {items.inBound[0].airline}-
                                      {items.inBound[0].flightNo}
                                    </span>
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="col-span-5 px-14">
                              <div className="grid grid-cols-4">
                                <div className="text-center py-3">
                                  <span className="text-lg text-black font-bold">
                                    {items.inBound[0].depDate}{" "}
                                  </span>
                                  <span className="text-lg text-black font-bold">
                                    {items.inBound[0].fromAirport}
                                  </span>
                                </div>
                                <div className="col-span-2">
                                  <div className="grid grid-cols-10 mt-3 sd-1">
                                    <div className="col-span-4 pl-2">
                                      <Image
                                        src={plane}
                                        width={50}
                                        height={50}
                                        className="-top-5 relative"
                                      />
                                    </div>
                                    <div className="col-span-2 text-center relative -top-2">
                                      <span className="text-xs text-black font-sans">
                                        2h
                                      </span>
                                      <br />
                                      <span className="text-xs text-black font-sans">
                                        Non-Stop
                                      </span>
                                    </div>
                                    <div className="col-span-4 pr-2">
                                      <Image
                                        src={plane}
                                        width={50}
                                        height={50}
                                        className="-top-5 relative"
                                      />
                                    </div>
                                  </div>
                                </div>
                                <div className="text-center py-3">
                                  <span className="text-lg text-black font-bold">
                                    {items.inBound[0].reachDate}{" "}
                                  </span>
                                  <span className="text-lg text-black font-bold">
                                    {items.inBound[0].toAirport}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div>
                              {/* <div className="grid grid-cols-4">
                      <div className="text-right px-2 pt-0 mb-4">
                        <span className=" text-lg font-bold text-black font-sans">
                          From
                        </span>
                      </div>
                      <div className="pl-4 col-span-3">
                        <span className="text-lg font-bold text-black font-sans">
                          <i class="fa fa-rupee-sign fa-sm "></i>{" "}
                        {items.fare.grandTotal}
                        </span>
                        <br />
                      </div>
                    </div> */}
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                <Row className="my-4">
                  <Col
                    xs={12}
                    xl={4}
                    className="d-flex align-items-center mb-3"
                  >
                    <div className="pr-2">
                      <div className="faround-rfun d-flex align-items-center">
                        <i class="fa fa-briefcase fa-lg"></i>
                      </div>
                    </div>
                    <div className="pl-2 pt-1">
                      <p className="font-semibold mb-0 text-xlbbage text-black">
                        Cabin Baggage
                      </p>
                      <span className="text-base text-gray-500 font-medium text-xlbbage-sm">
                        7Kg per person
                      </span>
                    </div>
                  </Col>

                  <Col
                    xs={12}
                    xl={4}
                    className="d-flex align-items-center mb-3"
                  >
                    <div className="pr-2">
                      <div className="faround-rfun d-flex align-items-center">
                        <i class="fa fa-luggage-cart fa-lg"></i>
                      </div>
                    </div>
                    <div className="pl-2 pt-1">
                      <p className="font-semibold mb-0 text-xlbbage text-black">
                        Check-In Baggage
                      </p>
                      <span className="text-base text-gray-500 font-medium text-xlbbage-sm">
                        15Kg Per person
                      </span>
                    </div>
                  </Col>

                  <Col xs={12} xl={4} className="d-flex align-items-center">
                    <div className="pr-2">
                      <div className="faround-rfun d-flex align-items-center">
                        <i class="fa fa-exchange-alt fa-lg"></i>
                      </div>
                    </div>
                    <div className="pl-2">
                      <p className="font-semibold mb-0 text-xlbbage text-black">
                        Refundable
                      </p>
                    </div>
                  </Col>
                </Row>

                <div className="footer-checkfare">
                  <Row className="align-items-center">
                    <Col xs={12} md={8}>
                      <span className="text-2xl grandtotal-fr font-bold text-black">
                        <span className="text-gray-600  font-medium">
                          Grand Total
                        </span>
                        <span className="ml-3 mr-1">
                          ₹{/* <i class="fa fa-rupee-sign fa-sm"></i> */}
                        </span>

                        {items.fare.grandTotal * data.totalpassanger}
                      </span>
                    </Col>
                    <Col xs={12} md={4}>
                      <button
                        className="btn btn-siteorange done-vel"
                        onClick={() => checkFare_Rule(items)}
                      >
                        Continue
                      </button>
                    </Col>
                  </Row>
                </div>
              </>
            )
          )}
        </Modal.Body>
      </Modal>
      {/*----------------------- book Now--------------------------- */}

      {/* ------------------------------load---------------------------- */}
      <Modal className="fetching" show={show2} onHide={handleClose2}>
        <ModalBody className="">
          <Image src={loaders} width={540} height={260} />
          {/* <h4 className="text-center">Please wai</h4> */}
        </ModalBody>
      </Modal>

      {/* ------------------------------load---------------------------- */}
    </div>
  );
};
export default Dom_Int_OneWay;
